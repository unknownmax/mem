/******************************************************************************
 * @brief    ϵͳ�����ļ�
 *
 * Copyright (c) 2019, <morro_luo@163.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 ******************************************************************************/

#ifndef _CONFIG_H_
#define _CONFIG_H_

#define APP_ADDRESS      0x08004000                    //Ӧ�ó���ʼ��ַ

#define SW_VER           "1.00"                        //�����汾��

#endif
